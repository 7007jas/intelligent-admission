# Contributions

## Danesh Badlani

* Created the EDA
* Added most of the initial models (SVM, KNN, DT, Random Forest)
* Created the threshold for the 'Chance of Admit ' feature
* Added metrics to all models
* Created and tuned the DT model
* Tuned SVM

## Sam Bluestone

* Categorized the 'Race' feature
* Created the Naïve Bayes model
* Plotting with most of the models
* Tuned the DT model

## Leslie Le

* Added the initial decision tree and linear regression models
* Plotting with KNN
* Small amount of tuning with models

All contributed to the README document.
